=== Message of the Day ===
Contributors: Brian Retterer
Stable tag: 0.1.0
Tested up to: 6.4
Requires at least: 4.6

== Description ==
Just a plugin to test the updator from Github.